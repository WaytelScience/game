from singletons import SingletonMeta


class Blocked_positions(metaclass=SingletonMeta):
    """
    Заблокированные игроком с позиции
    """

    def __init__(self):
        self.blocked_positions = []

    def add_block_position(self, player_c_position):
        self.blocked_positions += player_c_position

    def print_blocked(self):
        print('Заблокированные позиции: ', self.blocked_positions)

    def get_blocked_list(self):
        return self.blocked_positions
