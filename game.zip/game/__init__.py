from game import Game


def main():
    Game().play()


if __name__ == '__main__':
    main()